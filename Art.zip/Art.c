/*
 * Created by: 	Rachel Poppe
 * Date: 		4/17/2020
 * Username: 	rmpoppe
 * Program Name: Art.c
 * Description: Prints a greyscale file as ascii art with a border
*/

#include <stdlib.h>
#include <stdio.h>

// Draws a horizontal line of specified length
void drawLine(int length);

// Prints an ascii art char followed by a space
void printChar(double greyVal);

int main(int argc, char** argv)
{
	double delta = 0;
	if (argc > 1)
		delta = atof(argv[1]);

	int rows, cols;
	scanf("%d %d\n", &rows, &cols);

	drawLine(cols);
	for (int i = 0; i < rows; i++)
	{
		printf("|");
		for (int j = 0; j < cols; j++)
		{
			double greyVal;
			scanf("%lf", &greyVal);
			printChar(greyVal + delta);
		}
		printf("|\n");
	}
	drawLine(cols);
}

void drawLine(int length)
{
	printf("+");
	for (int i = 0; i < length; i++)
		printf("-");
	printf("+\n");
}

void printChar(double greyVal)
{
	if (greyVal < 0.2)
		printf(" ");
	else if (greyVal < 0.4)
		printf(".");
	else if (greyVal < 0.6)
		printf("o");
	else if (greyVal < 0.8)
		printf("O");
	else
		printf("@");
}
