/*
 * Created by: 	Rachel Poppe
 * Date: 		4/17/2020
 * Username: 	rmpoppe
 * Program Name: Combine.c
 * Description: Combines one or more greyscale files into one greyscale file based on a mask specifying pixel origins
*/

#include <stdlib.h>
#include <stdio.h>
#include <float.h>

// Struct containing stats about an array of doubles
struct Stats
{
	int count;
	double min;
	double max;
	double sum;
	double mean;
};

// Fills in a struct stats based on the given array
void computeStatsFromDouble2D(struct Stats* stats, double* array, int size);

// Prints given struct Stats
void printStats(struct Stats* stats);

// Struct containing mask file and related data
struct Mask
{
	FILE* file;
	int rows;
	int cols;
	int* values;
	int numGreyFiles;
};

// mallocs all necessary memory and opens mask file
struct Mask maskConstructer(char* name);

// frees all associated memory and closes mask file
void maskDestructer(struct Mask mask);

// Gets 2 ints from a file and returns them, very useful in getting rows & cols
void getTwoInts(FILE* file, int* intOne, int* intTwo);

// Writes an array to a given file
int writeDouble2DArrayToFile(char* fileName, int rows, int cols, double* array);


int main(int argc, char** argv)
{
	if (argc < 4)
	{
		printf("Combine <mask file> <output file> <grey file0> [grey file1] ...\n");
		return 1;
	}

	char* maskName = argv[1];
	printf("Opening '%s' for input\n", maskName);
	struct Mask mask = maskConstructer(maskName);
	if (mask.file == NULL)
	{
		printf("ERROR: Can't open '%s' for input!\n", maskName);
		return 1;
	}

	printf("Mask size: %d x %d\n", mask.rows, mask.cols);
	int* pixelValCounts = calloc(1, sizeof(int));
	mask.numGreyFiles = 1;
	//fill mask.values and collect info about the data
	for (int i = 0; i < mask.rows * mask.cols; i++)
	{
		fscanf(mask.file, "%d", &mask.values[i]);
		//if the mask value has been seen before
		if (mask.values[i] < mask.numGreyFiles)
		{
			//just increment that value
			pixelValCounts[mask.values[i]]++;
		}
		else
		{
			//this value hasn't been seen before so we need a new slot for it
			//realloc array to somewhere with enough space
			int* temp = realloc(pixelValCounts, sizeof(int) * (mask.numGreyFiles + 1));
			if (temp != NULL)
				pixelValCounts = temp;
			else
			{
				//array cannot be extended so free all memory and stop the program
				maskDestructer(mask);
				free(pixelValCounts);
				pixelValCounts = NULL;
				return 1;
			}
			//set the count to 1 because we have now seen the value once
			pixelValCounts[mask.values[i]] = 1;
			//increase known length of array
			mask.numGreyFiles++;
		}
	}

	//print mask value percents
	for (int i = 0; i < mask.numGreyFiles; ++i)
	{
		double percent = (double)pixelValCounts[i] / (mask.rows * mask.cols) * 100;
		printf("Mask %d: %.2lf%%\n", i, percent);
	}

	//this value is not used in the rest of the program
	free(pixelValCounts);
	pixelValCounts = NULL;

	//open all grey files
	int numGreyFiles = argc - 3;
	FILE** files = malloc(sizeof(FILE*) * numGreyFiles);
	for (int i = 0; i < numGreyFiles; ++i)
	{
		printf("Opening '%s' for input\n", argv[i + 3]);
		files[i] = fopen(argv[i + 3], "r");
		if (files[i] == NULL)
		{
			printf("ERROR: Can't open '%s' for input!\n", argv[i + 3]);
			//close all previous files
			for (int j = 0; j < i; ++j)
			{
				fclose(files[j]);
				files[j] = NULL;
			}
			return 1;
		}

		int rows, cols;
		getTwoInts(files[i], &rows, &cols);
		if ((rows != mask.rows) || (cols != mask.cols))
		{
			printf("ERROR: Input file '%s' size %d x %d invalid!\n", argv[i + 3], rows, cols);
			//close all previous files
			for (int j = 0; j <= i; ++j)
			{
				fclose(files[j]);
				files[j] = NULL;
			}
			return 1;
		}
	}

	double* valAtFiles = malloc(sizeof(double) * numGreyFiles);
	double* outArray = malloc(sizeof(double) * mask.cols * mask.rows);

	//read from files and select input as necessary
	for (int i = 0; i < mask.rows * mask.cols; ++i)
	{
		//read from files
		for (int j = 0; j < numGreyFiles; ++j)
		{
			fscanf(files[j], "%lf", &valAtFiles[j]);
		}
		//output correct value to array
		if (mask.values[i] > numGreyFiles)
			outArray[i] = 0;
		else
			outArray[i] = valAtFiles[mask.values[i]];
	}

	//this value is not used in the rest of the program
	free(valAtFiles);
	valAtFiles = NULL;

	int failed = writeDouble2DArrayToFile(argv[2], mask.rows, mask.cols, outArray);
	if (failed)
	{
		free(outArray);
		outArray = NULL;
		maskDestructer(mask);
		return 1;
	}

	struct Stats outStats;
	computeStatsFromDouble2D(&outStats, outArray, mask.rows * mask.cols);
	printStats(&outStats);

	//close all grey files
	for (int i = 0; i < numGreyFiles; ++i)
	{
		fclose(files[i]);
		files[i] = NULL;
	}

	free(outArray);
	outArray = NULL;
	maskDestructer(mask);
	return 0;
}

// Function implementations
void computeStatsFromDouble2D(struct Stats* stats, double* array, int size)
{
	stats->count = size;
	stats->sum = 0;
	stats->min = DBL_MAX;
	stats->max = -DBL_MAX;
	for (int i = 0; i < size; ++i)
	{
		stats->sum += array[i];
		if (array[i] < stats->min)
			stats->min = array[i];
		if (array[i] > stats->max)
			stats->max = array[i];
	}
	stats->mean = stats->sum / stats->count;
}

void printStats(struct Stats* stats)
{
	printf("count = %d, mean = %.6lf, min = %.6lf, max = %.6lf\n",
			stats->count, stats->mean, stats->min, stats->max);
}

struct Mask maskConstructer(char* name)
{
	struct Mask mask;
	mask.file = fopen(name, "r");
	getTwoInts(mask.file, &mask.rows, &mask.cols);
	mask.values = malloc(sizeof(int) * mask.rows * mask.cols);
	return mask;
}

void maskDestructer(struct Mask mask)
{
	fclose(mask.file);
	mask.file = NULL;
	free(mask.values);
	mask.values = NULL;
}

void getTwoInts(FILE* file, int* intOne, int* intTwo)
{
	fscanf(file, "%d %d\n", intOne, intTwo);
}

int writeDouble2DArrayToFile(char* fileName, int rows, int cols, double* array)
{
	printf("Opening '%s' for output\n", fileName);
	FILE* out = fopen(fileName, "w");
	if (out == NULL)
	{
		printf("Failed to open '%s' for output!\n", fileName);
		return 1;
	}

	fprintf(out, "%d %d\n", rows, cols);

	int index = 0;
	for (int i = 0; i < rows; ++i)
	{
		for (int j = 0; j < cols; ++j)
		{
			fprintf(out, "%lf ", array[index]);
			index++;
		}
		fprintf(out, "\n");
	}

	return 0;
}
