/*
 * Created by: 	Rachel Poppe
 * Date: 		4/15/2020
 * Username: 	rmpoppe
 * Program Name: Greyscale.c
 * Description: Converts a RGB image to greyscale
*/

#include <stdio.h>

/*
 * Input:  standard input from console
 * Output: integers r, b, g represent the values at a given pixel
 */
void scanPixel(int* pr, int* pg, int* pb);

/*
 * Input:  double representing the greyscale value
 * Output: prints value to the console
 */
void printPixel(double greyVal);

/*
 * Input:  rgb values at a pixel
 * Output: greyscale value based on rgb
 */
double rgbToGrey(int r, int g, int b);

int main()
{
	int rows, cols;
	scanf("%d %d\n", &rows, &cols);
	printf("%d %d\n", rows, cols);

	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < cols; j++)
		{
			int rVal, gVal, bVal;
			scanPixel(&rVal, &gVal, &bVal);
			double greyVal = rgbToGrey(rVal, gVal, bVal);
			printPixel(greyVal);
		}
		printf("\n");
	}

	return 0;
}

void scanPixel(int* pr, int* pg, int* pb)
{
	scanf("%d", pr);
	scanf("%d", pg);
	scanf("%d", pb);
}

void printPixel(double greyVal)
{
	printf("%.6f ", greyVal);
}

double rgbToGrey(int r, int g, int b)
{
	double rGrey = (0.299 * ( (double)r / 255) );
	double gGrey = (0.587 * ( (double)g / 255) );
	double bGrey = (0.114 * ( (double)b / 255) );
	return rGrey + gGrey + bGrey;
}
